int solve1(int* matrix,int n,int m,int x,int y,int a,int b){
    //TODO
    return 0;
}