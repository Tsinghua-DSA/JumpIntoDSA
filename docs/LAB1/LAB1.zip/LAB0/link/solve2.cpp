int solve2(int* matrix,int n,int m,int x,int y,int a,int b){
    //TODO
    static bool initiated = false;
    return 0;
}